// src/components/Profile.js
import React from 'react';

const Profile = () => {
    return (
        <div className="profile-container">
            <h2>Profile</h2>
            <p>Profile details will be displayed here.</p>
        </div>
    );
};

export default Profile;
